from typing import Dict, Sequence, Tuple

import numpy as np
import pandas as pd

from scipy.spatial.distance import pdist, squareform
from scipy.cluster.hierarchy import linkage, leaves_list

import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.cm import get_cmap

def plot_boot_barplot(boot_G_raw: Dict[str, Sequence[float]], tblG: pd.DataFrame, title: str = "Bootstrap PRISM-G") -> Tuple[plt.Figure, plt.Axes]:
    order = tblG.sort_values("mean_G", ascending=True)["name"].tolist()
    data  = [np.asarray(boot_G_raw[n], dtype=float) for n in order]

    means = np.array([d.mean() for d in data])
    sds   = np.array([d.std(ddof=1) for d in data])

    cmap = get_cmap("RdYlGn_r")      
    norm = Normalize(vmin=0, vmax=100)
    colors = [cmap(norm(m)) for m in means]

    fig, ax = plt.subplots(figsize=(9, 5))
    x = np.arange(len(order))
    bars = ax.bar(x, means, yerr=sds, capsize=4)

    for bar, c in zip(bars, colors):
        bar.set_color(c)

    ax.set_xticks(x)
    ax.set_xticklabels(order, rotation=25, ha="right")
    ax.set_ylabel("PRISM-G (0 = safer, 100 = riskier)")
    ax.set_title(title)
    ax.set_ylim(0, 100)
    ax.grid(axis="y", alpha=0.25)

    sm = plt.cm.ScalarMappable(norm=norm, cmap=cmap)
    sm.set_array([])
    fig.colorbar(sm, ax=ax, pad=0.02, label="PRISM-G Score")

    fig.tight_layout()
    return fig, ax

def plot_prismg_summary(df, title="PRISM-G (0 = safer, 100 = riskier)"):
    df_cand = df[df["role"] == "candidate"].sort_values("PRISM_G")

    labels = df_cand["name"].tolist()
    values = df_cand["PRISM_G"].tolist()

    # 2. Colormap (green → red)
    cmap = get_cmap("RdYlGn_r")
    norm = Normalize(vmin=0, vmax=100)
    colors = [cmap(norm(v)) for v in values]

    # 3. Barplot
    fig, ax = plt.subplots(figsize=(9, 5))
    x = np.arange(len(values))

    ax.bar(x, values, color=colors)

    # Axes formatting
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=30, ha="right")
    ax.set_ylabel("PRISM-G (0 = safer, 100 = riskier)")
    ax.set_ylim(0, 100)
    ax.set_title(title)
    ax.grid(axis="y", alpha=0.3)

    # 4. Colorbar
    sm = plt.cm.ScalarMappable(norm=norm, cmap=cmap)
    sm.set_array([])
    fig.colorbar(sm, ax=ax, pad=0.02, label="PRISM-G Score")

    fig.tight_layout()
    return fig, ax

def _cluster_and_reorder(matrix, method="ward", metric="euclidean"):
    """
    Cluster rows and columns of `matrix` hierarchically and return
    the reordered matrix plus the leaf order indices.
    """
    X = np.asarray(matrix)

    # Row clustering
    row_dist = pdist(X, metric=metric)
    row_link = linkage(row_dist, method=method)
    row_order = leaves_list(row_link)

    # Column clustering
    col_dist = pdist(X.T, metric=metric)
    col_link = linkage(col_dist, method=method)
    col_order = leaves_list(col_link)

    X_reordered = X[row_order][:, col_order]
    return X_reordered, row_order, col_order


def plot_side_by_side_heatmaps(G_ho, G_syn,
    method="ward",
    metric="euclidean",
    figsize=(12, 5),
    cmap="viridis",
    vmin=None,
    vmax=None,
    title_ho="a) G_ho",
    title_syn="b) G_syn",
):
    G_ho = np.asarray(G_ho)
    G_syn = np.asarray(G_syn)

    # Cluster & reorder both matrices independently
    G_ho_reord, ho_row_order, ho_col_order = _cluster_and_reorder(
        G_ho, method=method, metric=metric
    )
    G_syn_reord, syn_row_order, syn_col_order = _cluster_and_reorder(
        G_syn, method=method, metric=metric
    )

    # Shared color scale if not provided
    if vmin is None:
        vmin = min(G_ho_reord.min(), G_syn_reord.min())
    if vmax is None:
        vmax = max(G_ho_reord.max(), G_syn_reord.max())

    fig, axes = plt.subplots(1, 2, figsize=figsize, constrained_layout=True)

    im0 = axes[0].imshow(G_ho_reord, aspect="auto", cmap=cmap, vmin=vmin, vmax=vmax)
    axes[0].set_title(title_ho)
    axes[0].set_xlabel("Features")
    axes[0].set_ylabel("Samples")

    im1 = axes[1].imshow(G_syn_reord, aspect="auto", cmap=cmap, vmin=vmin, vmax=vmax)
    axes[1].set_title(title_syn)
    axes[1].set_xlabel("Features")
    axes[1].set_ylabel("Samples")

    # Shared colorbar
    cbar = fig.colorbar(im1, ax=axes.ravel().tolist(), shrink=0.8)
    cbar.set_label("Value")

    return fig, axes